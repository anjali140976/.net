﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace prac7a.Models
{
    public class Feedback
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Enter Enrollment Number")]
        public string EnrollmentNo { get; set; }

        [Required(ErrorMessage = "Please enter your name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Enter Subject")]

        public string Subject { get; set; }


        [Required(ErrorMessage = "Select Rating")]
        public int Rating { get; set; }


        [Required(ErrorMessage = "Enter Comment")]
        public string Comment { get; set; }

    }
}