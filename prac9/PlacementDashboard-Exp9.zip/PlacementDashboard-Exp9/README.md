# Experiment 9 - Placement Dashboard (ASP.NET Core Razor Pages + MongoDB)

- ASP.NET Core Razor Pages (.NET 10)
- MongoDB.Driver 3.13.0
- Database: `PlacementDB` -> collections `Students`, `Companies`, `Placements`

## Run kaise kare (Visual Studio 2022 / 2026 ya terminal)
1. **.NET 10 SDK** install hona chahiye (`dotnet --version`).
2. **MongoDB Community Server** install karke chalu rakho (`mongodb://localhost:27017`).
   Connection string `appsettings.json` me change kar sakte ho.
3. `PlacementDashboard.sln` open karo -> **https** profile se `F5`.
   Ya terminal me:
   ```
   cd PlacementDashboard
   dotnet run
   ```
4. Pehli baar page khulne par sample data (8 students, 6 companies, 6 placements) apne aap insert ho jata hai.

Pages: `/` Dashboard, `/Students`, `/Companies`, `/Placements`, `/Reports`
