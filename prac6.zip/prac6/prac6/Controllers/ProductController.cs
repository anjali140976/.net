﻿using Microsoft.AspNetCore.Mvc;
using prac6.Models;
using System.Collections.Generic;

namespace prac6.Controllers
{
    public class ProductController : Controller
    {
        public IActionResult Index()
        {
            // Main list of products
            List<Product> p = new List<Product>();

            // Product 1
            Product p1 = new Product
            {
                Id = 1,
                Name = "Laptop",
                Category = "Electronics",
                Price = 55000,
                Image = "laptop.jpg"
            };

            // Product 2
            Product p2 = new Product
            {
                Id = 2,
                Name = "Mobile",
                Category = "Electronics",
                Price = 25000,
                Image = "mobile.jpg"
            };

            // Product 3
            Product p3 = new Product
            {
                Id = 3,
                Name = "Headphones",
                Category = "Accessories",
                Price = 2500,
                Image = "headphones.jpg"
            };

            // Append products into list
            p.Add(p1);
            p.Add(p2);
            p.Add(p3);

            return View(p);
        }
    }
}