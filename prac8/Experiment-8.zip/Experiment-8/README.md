# Experiment 8 - Inventory Management Module (ADO.NET + CRUD)

ASP.NET MVC 5 (.NET Framework 4.8) + ADO.NET (SqlClient) + SQL Server LocalDB.

## Run kaise kare (Visual Studio 2022)
1. `ProductModuleInventory.sln` open karo.
2. Solution par right-click -> **Restore NuGet Packages** (VS khud bhi karta hai).
3. `F5` se run karo -> `http://localhost:44319/Product/Index`.
4. Pehli run par database `inventerydb` aur table `Products` apne aap ban jaata hai
   (ya `Database/inventerydb.sql` manually run kar sakte ho).

## Requirements
- Visual Studio 2022 with **ASP.NET and web development** workload
- .NET Framework 4.8 targeting pack
- SQL Server LocalDB (VS ke saath aata hai)
