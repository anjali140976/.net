using System.Configuration;
using System.Data.SqlClient;

namespace ProductModuleInventory.Data
{
    // App pehli baar chalte hi database + Products table khud bana deta hai
    public static class DbInitializer
    {
        public static void Initialize()
        {
            string cs = ConfigurationManager.ConnectionStrings["InventoryDb"].ConnectionString;
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(cs);
            string dbName = builder.InitialCatalog;

            // 1) Database banao (agar nahi hai)
            builder.InitialCatalog = "master";
            using (SqlConnection con = new SqlConnection(builder.ConnectionString))
            {
                con.Open();
                string sql = "IF DB_ID(N'" + dbName + "') IS NULL CREATE DATABASE [" + dbName + "]";
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    cmd.ExecuteNonQuery();
                }
            }

            // 2) Table banao (agar nahi hai)
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                string sql = @"
IF OBJECT_ID(N'dbo.Products', N'U') IS NULL
CREATE TABLE dbo.Products
(
    ProductId   INT IDENTITY(1,1) PRIMARY KEY,
    ProductName VARCHAR(100) NOT NULL,
    Quantity    INT NOT NULL,
    Price       DECIMAL(10,2) NOT NULL
)";
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
