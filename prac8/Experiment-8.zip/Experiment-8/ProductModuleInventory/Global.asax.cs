using System;
using System.Web.Mvc;
using System.Web.Routing;
using ProductModuleInventory.Data;

namespace ProductModuleInventory
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);

            try
            {
                DbInitializer.Initialize();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("DB init failed: " + ex.Message);
            }
        }
    }
}
