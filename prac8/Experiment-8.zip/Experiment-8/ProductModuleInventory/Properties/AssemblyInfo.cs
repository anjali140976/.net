using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ProductModuleInventory")]
[assembly: AssemblyDescription("Inventory Management Module using ADO.NET and CRUD")]
[assembly: AssemblyProduct("ProductModuleInventory")]
[assembly: ComVisible(false)]
[assembly: Guid("b7f3a2d1-5c4e-4a9b-8e21-3d6f9a1c7e54")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
