<%@ Application Codebehind="Global.asax.cs" Inherits="ProductModuleInventory.MvcApplication" Language="C#" %>
