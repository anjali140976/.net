-- Optional: app khud DB banata hai, but manually chahiye to ye run karo
IF DB_ID(N'inventerydb') IS NULL CREATE DATABASE inventerydb;
GO
USE inventerydb;
GO
IF OBJECT_ID(N'dbo.Products', N'U') IS NULL
CREATE TABLE dbo.Products
(
    ProductId   INT IDENTITY(1,1) PRIMARY KEY,
    ProductName VARCHAR(100) NOT NULL,
    Quantity    INT NOT NULL,
    Price       DECIMAL(10,2) NOT NULL
);
GO
